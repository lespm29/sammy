import React from 'react'

function SobreNosotros() {
    return (
        <div>
            <h1>Esta es la página sobre nosotros</h1>
            <h1>SI es la Pagina alquilado sobre mi</h1>
        </div>
    )
}

export default SobreNosotros