import { Link } from "react-router-dom";
import Navbar from "./Componentes/Navbar";

function CitasAmigos() {
  return (
    <div>
      <Navbar />
      <h1 style={{color:'white'}}>CitasAmigos</h1>
    </div>      
  );
}

export default CitasAmigos;
